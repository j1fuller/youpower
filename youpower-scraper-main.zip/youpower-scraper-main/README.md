Author: SupportDone.com
SupportDone.com is a platform dedicated to providing reliable support and resources for developers.

pyinstaller --onefile --noconsole --icon=icon.ico --clean --name="youpower" --version-file="version_info.txt" youpower.py